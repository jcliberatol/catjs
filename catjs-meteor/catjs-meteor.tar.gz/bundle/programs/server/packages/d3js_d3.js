(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['d3js:d3'] = {};

})();

//# sourceMappingURL=d3js_d3.js.map
